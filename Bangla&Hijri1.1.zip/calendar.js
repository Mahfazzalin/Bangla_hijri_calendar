// Bangla months
const banglaMonths = [
    'বৈশাখ', 'জ্যৈষ্ঠ', 'আষাঢ়', 'শ্রাবণ', 'ভাদ্র', 'আশ্বিন',
    'কার্তিক', 'অগ্রহায়ণ', 'পৌষ', 'মাঘ', 'ফাল্গুন', 'চৈত্র'
];

// Hijri months
const hijriMonths = [
    'মুহাররম', 'সফর', 'রবিউল আউয়াল', 'রবিউস সানি', 'জমাদিউল আউয়াল', 'জমাদিউস সানি',
    'রজব', 'শাবান', 'রমজান', 'শাওয়াল', 'জ্বিলকদ', 'জ্বিলহজ্জ'
];

// Bangla numerals
const banglaNumbers = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];

// Convert English number to Bangla
function toBanglaNumber(num) {
    return num.toString().split('').map(d => banglaNumbers[parseInt(d)] || d).join('');
}

// Calculate Bangla date (Bengali Calendar - modified from Gregorian)
function getBanglaDate(date) {
    // Adjust for Bangladesh - one day behind
    const adjustedDate = new Date(date);
    adjustedDate.setDate(adjustedDate.getDate() - 1);
    
    const gYear = adjustedDate.getFullYear();
    const gMonth = adjustedDate.getMonth() + 1; // 1-12
    const gDay = adjustedDate.getDate();
    
    let bYear, bMonth, bDay;
    
    // Bengali New Year starts on April 14 (or April 15 in leap years after 2020)
    if (gMonth < 4 || (gMonth === 4 && gDay < 14)) {
        // Before April 14 = Previous Bengali year (Magh, Falgun, Chaitra)
        bYear = gYear - 594;
    } else {
        // After April 14 = Current Bengali year
        bYear = gYear - 593;
    }
    
    // Month mapping based on Gregorian dates
    // First 5 months (Boishakh to Bhadro) have 31 days
    // Last 7 months (Ashwin to Chaitra) have 30 days
    
    if (gMonth === 4 && gDay >= 14) {
        // Boishakh (April 14 - May 14)
        bMonth = 0;
        bDay = gDay - 13;
    } else if (gMonth === 5 && gDay <= 14) {
        bMonth = 0;
        bDay = 18 + gDay;
    } else if (gMonth === 5 && gDay >= 15) {
        // Jyoishtho (May 15 - June 14)
        bMonth = 1;
        bDay = gDay - 14;
    } else if (gMonth === 6 && gDay <= 14) {
        bMonth = 1;
        bDay = 17 + gDay;
    } else if (gMonth === 6 && gDay >= 15) {
        // Asharh (June 15 - July 15)
        bMonth = 2;
        bDay = gDay - 14;
    } else if (gMonth === 7 && gDay <= 15) {
        bMonth = 2;
        bDay = 17 + gDay;
    } else if (gMonth === 7 && gDay >= 16) {
        // Shrabon (July 16 - August 15)
        bMonth = 3;
        bDay = gDay - 15;
    } else if (gMonth === 8 && gDay <= 15) {
        bMonth = 3;
        bDay = 16 + gDay;
    } else if (gMonth === 8 && gDay >= 16) {
        // Bhadro (August 16 - September 15)
        bMonth = 4;
        bDay = gDay - 15;
    } else if (gMonth === 9 && gDay <= 15) {
        bMonth = 4;
        bDay = 16 + gDay;
    } else if (gMonth === 9 && gDay >= 16) {
        // Ashwin (September 16 - October 15)
        bMonth = 5;
        bDay = gDay - 15;
    } else if (gMonth === 10 && gDay <= 15) {
        bMonth = 5;
        bDay = 16 + gDay;
    } else if (gMonth === 10 && gDay >= 16) {
        // Kartik (October 16 - November 14)
        bMonth = 6;
        bDay = gDay - 15;
    } else if (gMonth === 11 && gDay <= 14) {
        bMonth = 6;
        bDay = 16 + gDay;
    } else if (gMonth === 11 && gDay >= 15) {
        // Ogrohayon (November 15 - December 14)
        bMonth = 7;
        bDay = gDay - 14;
    } else if (gMonth === 12 && gDay <= 14) {
        bMonth = 7;
        bDay = 16 + gDay;
    } else if (gMonth === 12 && gDay >= 15) {
        // Poush (December 15 - January 13)
        bMonth = 8;
        bDay = gDay - 14;
    } else if (gMonth === 1 && gDay <= 13) {
        bMonth = 8;
        bDay = 17 + gDay;
    } else if (gMonth === 1 && gDay >= 14) {
        // Magh (January 14 - February 12)
        bMonth = 9;
        bDay = gDay - 13;
    } else if (gMonth === 2 && gDay <= 12) {
        bMonth = 9;
        bDay = 18 + gDay;
    } else if (gMonth === 2 && gDay >= 13) {
        // Falgun (February 13 - March 14)
        bMonth = 10;
        bDay = gDay - 12;
    } else if (gMonth === 3 && gDay <= 14) {
        bMonth = 10;
        bDay = 17 + gDay;
    } else if (gMonth === 3 && gDay >= 15) {
        // Chaitra (March 15 - April 13)
        bMonth = 11;
        bDay = gDay - 14;
    } else if (gMonth === 4 && gDay <= 13) {
        bMonth = 11;
        bDay = 17 + gDay;
    }
    
    return {
        day: bDay,
        month: bMonth,
        year: bYear,
        monthName: banglaMonths[bMonth]
    };
}

// Calculate Hijri date using accurate algorithm
function getHijriDate(date) {
    // In Islamic calendar, day changes at sunset (approximately 6 PM)
    // If it's after 6 PM, we need to add one day to the date before conversion
    const adjustedDate = new Date(date);
    const hours = adjustedDate.getHours();
    
    // If after 6 PM (18:00), it's the next Islamic day
    if (hours >= 18) {
        adjustedDate.setDate(adjustedDate.getDate() + 1);
    }
    
    // Then apply Bangladesh's one day behind adjustment
    adjustedDate.setDate(adjustedDate.getDate() - 1);
    
    // Convert Gregorian to Julian Day Number
    const gYear = adjustedDate.getFullYear();
    const gMonth = adjustedDate.getMonth() + 1;
    const gDay = adjustedDate.getDate();
    
    let a = Math.floor((14 - gMonth) / 12);
    let y = gYear + 4800 - a;
    let m = gMonth + 12 * a - 3;
    
    let jdn = gDay + Math.floor((153 * m + 2) / 5) + 365 * y + 
              Math.floor(y / 4) - Math.floor(y / 100) + 
              Math.floor(y / 400) - 32045;
    
    // Convert Julian Day Number to Islamic Calendar
    let l = jdn - 1948440 + 10632;
    let n = Math.floor((l - 1) / 10631);
    l = l - 10631 * n + 354;
    let j = (Math.floor((10985 - l) / 5316)) * 
            (Math.floor((50 * l) / 17719)) + 
            (Math.floor(l / 5670)) * 
            (Math.floor((43 * l) / 15238));
    l = l - (Math.floor((30 - j) / 15)) * 
        (Math.floor((17719 * j) / 50)) - 
        (Math.floor(j / 16)) * 
        (Math.floor((15238 * j) / 43)) + 29;
    
    let hMonth = Math.floor((24 * l) / 709);
    let hDay = l - Math.floor((709 * hMonth) / 24);
    let hYear = 30 * n + j - 30;
    
    return {
        day: hDay,
        month: hMonth - 1, // 0-indexed
        year: hYear,
        monthName: hijriMonths[hMonth - 1]
    };
}

// Update date display
function updateDateDisplay() {
    const now = new Date();
    const bangla = getBanglaDate(now);
    const hijri = getHijriDate(now);
    
    document.getElementById('banglaDate').textContent = 
        `${toBanglaNumber(bangla.day)} ${bangla.monthName}, ${toBanglaNumber(bangla.year)}`;
    
    document.getElementById('hijriDate').textContent = 
        `${toBanglaNumber(hijri.day)} ${hijri.monthName}, ${toBanglaNumber(hijri.year)}`;
    
    document.getElementById('gregorianDate').textContent = 
        now.toLocaleDateString('bn-BD', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
        });
}

// Generate calendar for a given month
function generateCalendar(year, month, type, currentDay) {
    const daysInMonth = type === 'bangla' ? 
        (month < 5 ? 31 : 30) : // Bengali: first 5 months have 31 days
        (month % 2 === 0 ? 30 : 29); // Hijri: alternating 30/29
    
    const calendar = [];
    
    // Add day headers
    const dayHeaders = ['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহ', 'শুক্র', 'শনি'];
    dayHeaders.forEach((day, index) => {
        calendar.push({ 
            type: 'header', 
            value: day,
            isFriday: index === 5 // Friday is index 5 (শুক্র)
        });
    });
    
    // Calculate starting day of week (simplified approximation)
    const startDay = (month * 2 + year) % 7;
    
    // Add empty cells
    for (let i = 0; i < startDay; i++) {
        calendar.push({ type: 'empty', value: '' });
    }
    
    // Add days
    for (let day = 1; day <= daysInMonth; day++) {
        const dayOfWeek = (startDay + day - 1) % 7;
        const hasEvents = hasEvent(type, day, month, year);
        calendar.push({ 
            type: 'date', 
            value: toBanglaNumber(day),
            isToday: day === currentDay,
            isFriday: dayOfWeek === 5, // Friday column
            hasEvent: hasEvents
        });
    }
    
    return calendar;
}

// Render calendar
function renderCalendar(containerId, calendar) {
    const container = document.getElementById(containerId);
    container.innerHTML = '';
    
    const calendarType = containerId === 'banglaCalendar' ? 'bangla' : 'hijri';
    
    calendar.forEach((day, index) => {
        const div = document.createElement('div');
        div.className = `calendar-day ${day.type}`;
        if (day.isToday) div.classList.add('today');
        if (day.isFriday) div.classList.add('friday');
        if (day.hasEvent) div.classList.add('has-event');
        div.textContent = day.value;
        
        // Add click event for date cells
        if (day.type === 'date') {
            div.addEventListener('click', () => {
                const dayNum = parseInt(day.value.split('').map(c => banglaNumbers.indexOf(c) >= 0 ? banglaNumbers.indexOf(c) : c).join(''));
                const month = calendarType === 'bangla' ? currentBangla.month : currentHijri.month;
                const year = calendarType === 'bangla' ? currentBangla.year : currentHijri.year;
                showDateEvents(calendarType, dayNum, month, year);
            });
        }
        
        container.appendChild(div);
    });
}

// Current calendar state
let currentBangla = getBanglaDate(new Date());
let currentHijri = getHijriDate(new Date());

// Update full calendar view
function updateCalendarView() {
    // Bangla calendar
    document.getElementById('banglaMonthYear').textContent = 
        `${banglaMonths[currentBangla.month]} ${toBanglaNumber(currentBangla.year)}`;
    const banglaCalendar = generateCalendar(
        currentBangla.year, 
        currentBangla.month, 
        'bangla',
        currentBangla.day
    );
    renderCalendar('banglaCalendar', banglaCalendar);
    
    // Hijri calendar
    document.getElementById('hijriMonthYear').textContent = 
        `${hijriMonths[currentHijri.month]} ${toBanglaNumber(currentHijri.year)}`;
    const hijriCalendar = generateCalendar(
        currentHijri.year, 
        currentHijri.month, 
        'hijri',
        currentHijri.day
    );
    renderCalendar('hijriCalendar', hijriCalendar);
}

// Event listeners
document.getElementById('openCalendarBtn').addEventListener('click', () => {
    document.getElementById('dateView').style.display = 'none';
    document.getElementById('calendarView').style.display = 'block';
    document.body.style.width = '350px';
    document.body.style.height = 'auto';
    updateCalendarView();
});

document.getElementById('backBtn').addEventListener('click', () => {
    document.getElementById('calendarView').style.display = 'none';
    document.getElementById('dateView').style.display = 'block';
    document.body.style.width = '320px';
});

document.getElementById('prevBangla').addEventListener('click', () => {
    currentBangla.month--;
    if (currentBangla.month < 0) {
        currentBangla.month = 11;
        currentBangla.year--;
    }
    updateCalendarView();
});

document.getElementById('nextBangla').addEventListener('click', () => {
    currentBangla.month++;
    if (currentBangla.month > 11) {
        currentBangla.month = 0;
        currentBangla.year++;
    }
    updateCalendarView();
});

document.getElementById('prevHijri').addEventListener('click', () => {
    currentHijri.month--;
    if (currentHijri.month < 0) {
        currentHijri.month = 11;
        currentHijri.year--;
    }
    updateCalendarView();
});

document.getElementById('nextHijri').addEventListener('click', () => {
    currentHijri.month++;
    if (currentHijri.month > 11) {
        currentHijri.month = 0;
        currentHijri.year++;
    }
    updateCalendarView();
});

// Initialize
updateDateDisplay();

// ============ EVENT MANAGEMENT ============

let events = [];
let editingEventId = null;
let selectedDateContext = null; // Store clicked date context

// Load events from Chrome storage
function loadEvents() {
    chrome.storage.local.get(['calendarEvents'], function(result) {
        events = result.calendarEvents || [];
        updateCalendarView();
        renderEventList();
    });
}

// Save events to Chrome storage
function saveEvents() {
    chrome.storage.local.set({ calendarEvents: events }, function() {
        updateCalendarView();
        renderEventList();
    });
}

// Add or update event
function saveEvent() {
    const title = document.getElementById('eventTitle').value.trim();
    const desc = document.getElementById('eventDesc').value.trim();
    const calendarType = document.getElementById('eventCalendarType').value;
    const dateStr = document.getElementById('eventDate').value;

    if (!title) {
        alert('অনুগ্রহ করে ইভেন্টের নাম লিখুন');
        return;
    }

    if (!dateStr) {
        alert('অনুগ্রহ করে তারিখ নির্বাচন করুন');
        return;
    }

    const selectedDate = new Date(dateStr);
    let eventDate;

    if (calendarType === 'bangla') {
        eventDate = getBanglaDate(selectedDate);
    } else {
        eventDate = getHijriDate(selectedDate);
    }

    const event = {
        id: editingEventId || Date.now(),
        title: title,
        description: desc,
        calendarType: calendarType,
        date: {
            day: eventDate.day,
            month: eventDate.month,
            year: eventDate.year
        },
        gregorianDate: dateStr
    };

    if (editingEventId) {
        const index = events.findIndex(e => e.id === editingEventId);
        if (index !== -1) {
            events[index] = event;
        }
        editingEventId = null;
    } else {
        events.push(event);
    }

    saveEvents();
    closeEventModal();
}

// Delete event
function deleteEvent(eventId) {
    if (confirm('আপনি কি এই ইভেন্টটি মুছে ফেলতে চান?')) {
        events = events.filter(e => e.id !== eventId);
        saveEvents();
        
        // Refresh the date events view if it's open
        if (selectedDateContext) {
            showDateEvents(
                selectedDateContext.calendarType,
                selectedDateContext.day,
                selectedDateContext.month,
                selectedDateContext.year
            );
        }
    }
}

// Edit event
function editEvent(eventId) {
    const event = events.find(e => e.id === eventId);
    if (!event) return;

    editingEventId = eventId;
    document.getElementById('modalTitle').textContent = 'ইভেন্ট সম্পাদনা করুন';
    document.getElementById('eventTitle').value = event.title;
    document.getElementById('eventDesc').value = event.description || '';
    document.getElementById('eventCalendarType').value = event.calendarType;
    document.getElementById('eventDate').value = event.gregorianDate;

    // Show the form section
    document.getElementById('dateEventsSection').style.display = 'none';
    document.getElementById('eventFormSection').style.display = 'block';
}

// Check if date has events
function hasEvent(calendarType, day, month, year) {
    return events.some(e => 
        e.calendarType === calendarType &&
        e.date.day === day &&
        e.date.month === month &&
        e.date.year === year
    );
}

// Get events for a date
function getEventsForDate(calendarType, day, month, year) {
    return events.filter(e => 
        e.calendarType === calendarType &&
        e.date.day === day &&
        e.date.month === month &&
        e.date.year === year
    );
}

// Render event list
function renderEventList() {
    const container = document.getElementById('eventsContainer');
    
    if (events.length === 0) {
        container.innerHTML = '<div class="no-events">কোন ইভেন্ট নেই</div>';
        return;
    }

    // Clear container
    container.innerHTML = '';
    
    // Create event items
    events.forEach(event => {
        const monthName = event.calendarType === 'bangla' 
            ? banglaMonths[event.date.month]
            : hijriMonths[event.date.month];
        
        const eventItem = document.createElement('div');
        eventItem.className = 'event-item';
        
        const eventTitle = document.createElement('div');
        eventTitle.className = 'event-title';
        eventTitle.textContent = event.title;
        eventItem.appendChild(eventTitle);
        
        if (event.description) {
            const eventDesc = document.createElement('div');
            eventDesc.className = 'event-desc';
            eventDesc.textContent = event.description;
            eventItem.appendChild(eventDesc);
        }
        
        const eventDate = document.createElement('div');
        eventDate.className = 'event-date';
        eventDate.textContent = `${toBanglaNumber(event.date.day)} ${monthName}, ${toBanglaNumber(event.date.year)} ${event.calendarType === 'bangla' ? '(বাংলা)' : '(হিজরি)'}`;
        eventItem.appendChild(eventDate);
        
        const eventActions = document.createElement('div');
        eventActions.className = 'event-actions';
        
        const editBtn = document.createElement('button');
        editBtn.className = 'btn-small';
        editBtn.textContent = 'সম্পাদনা';
        editBtn.addEventListener('click', () => editEvent(event.id));
        eventActions.appendChild(editBtn);
        
        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'btn-small btn-danger';
        deleteBtn.textContent = 'মুছুন';
        deleteBtn.addEventListener('click', () => deleteEvent(event.id));
        eventActions.appendChild(deleteBtn);
        
        eventItem.appendChild(eventActions);
        container.appendChild(eventItem);
    });
}

// Open event modal
function openEventModal() {
    document.getElementById('eventModal').classList.add('show');
    document.getElementById('dateEventsSection').style.display = 'none';
    document.getElementById('eventFormSection').style.display = 'block';
}

// Show events for a specific date
function showDateEvents(calendarType, day, month, year) {
    selectedDateContext = { calendarType, day, month, year };
    
    const monthName = calendarType === 'bangla' ? banglaMonths[month] : hijriMonths[month];
    const dateTitle = `${toBanglaNumber(day)} ${monthName}, ${toBanglaNumber(year)}`;
    
    document.getElementById('selectedDateTitle').textContent = dateTitle;
    document.getElementById('modalTitle').textContent = 'তারিখের ইভেন্ট';
    
    const dateEvents = getEventsForDate(calendarType, day, month, year);
    const dateEventsList = document.getElementById('dateEventsList');
    
    // Clear the list
    dateEventsList.innerHTML = '';
    
    if (dateEvents.length === 0) {
        dateEventsList.innerHTML = '<div class="no-events">এই তারিখে কোন ইভেন্ট নেই</div>';
    } else {
        // Create event items with proper event listeners
        dateEvents.forEach(event => {
            const eventItem = document.createElement('div');
            eventItem.className = 'event-item';
            
            const eventTitle = document.createElement('div');
            eventTitle.className = 'event-title';
            eventTitle.textContent = event.title;
            eventItem.appendChild(eventTitle);
            
            if (event.description) {
                const eventDesc = document.createElement('div');
                eventDesc.className = 'event-desc';
                eventDesc.textContent = event.description;
                eventItem.appendChild(eventDesc);
            }
            
            const eventActions = document.createElement('div');
            eventActions.className = 'event-actions';
            
            const editBtn = document.createElement('button');
            editBtn.className = 'btn-small';
            editBtn.textContent = 'সম্পাদনা';
            editBtn.addEventListener('click', () => editEvent(event.id));
            eventActions.appendChild(editBtn);
            
            const deleteBtn = document.createElement('button');
            deleteBtn.className = 'btn-small btn-danger';
            deleteBtn.textContent = 'মুছুন';
            deleteBtn.addEventListener('click', () => deleteEvent(event.id));
            eventActions.appendChild(deleteBtn);
            
            eventItem.appendChild(eventActions);
            dateEventsList.appendChild(eventItem);
        });
    }
    
    document.getElementById('dateEventsSection').style.display = 'block';
    document.getElementById('eventFormSection').style.display = 'none';
    document.getElementById('eventModal').classList.add('show');
}

// Quick add event for selected date
function quickAddEvent() {
    if (!selectedDateContext) return;
    
    document.getElementById('modalTitle').textContent = 'ইভেন্ট যোগ করুন';
    document.getElementById('eventCalendarType').value = selectedDateContext.calendarType;
    
    // Convert to Gregorian date for the date picker
    const gregorianDate = convertToGregorian(
        selectedDateContext.calendarType,
        selectedDateContext.day,
        selectedDateContext.month,
        selectedDateContext.year
    );
    document.getElementById('eventDate').value = gregorianDate;
    
    document.getElementById('dateEventsSection').style.display = 'none';
    document.getElementById('eventFormSection').style.display = 'block';
}

// Convert Bangla/Hijri to Gregorian (approximate)
function convertToGregorian(type, day, month, year) {
    const today = new Date();
    // This is a simplified approximation - you might want to refine this
    if (type === 'bangla') {
        const monthStart = [3, 4, 5, 6, 7, 8, 9, 10, 11, 0, 1, 2]; // Month mapping
        const gMonth = monthStart[month];
        const gYear = gMonth <= 2 ? year + 594 : year + 593;
        return `${gYear}-${String(gMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    } else {
        // Simplified Hijri to Gregorian
        return today.toISOString().split('T')[0];
    }
}

// Close event modal
function closeEventModal() {
    document.getElementById('eventModal').classList.remove('show');
    document.getElementById('modalTitle').textContent = 'ইভেন্ট যোগ করুন';
    document.getElementById('eventTitle').value = '';
    document.getElementById('eventDesc').value = '';
    document.getElementById('eventDate').value = '';
    document.getElementById('dateEventsSection').style.display = 'none';
    document.getElementById('eventFormSection').style.display = 'block';
    editingEventId = null;
    selectedDateContext = null;
}

// Event listeners for event management
document.getElementById('addEventBtn').addEventListener('click', openEventModal);
document.getElementById('closeModal').addEventListener('click', closeEventModal);
document.getElementById('saveEventBtn').addEventListener('click', saveEvent);
document.getElementById('quickAddBtn').addEventListener('click', quickAddEvent);

// Close modal on outside click
document.getElementById('eventModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeEventModal();
    }
});

// Load events on startup
loadEvents();