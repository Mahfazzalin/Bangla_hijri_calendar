// Bangla numerals
const banglaNumbers = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];

// Convert English number to Bangla
function toBanglaNumber(num) {
    return num.toString().split('').map(d => banglaNumbers[parseInt(d)] || d).join('');
}

// Calculate Bangla date
function getBanglaDate(date) {
    // Adjust for Bangladesh - one day behind
    const adjustedDate = new Date(date);
    adjustedDate.setDate(adjustedDate.getDate() - 1);
    
    const gYear = adjustedDate.getFullYear();
    const gMonth = adjustedDate.getMonth() + 1;
    const gDay = adjustedDate.getDate();
    
    let bYear, bMonth, bDay;
    
    if (gMonth < 4 || (gMonth === 4 && gDay < 14)) {
        bYear = gYear - 594;
    } else {
        bYear = gYear - 593;
    }
    
    if (gMonth === 4 && gDay >= 14) {
        bMonth = 0;
        bDay = gDay - 13;
    } else if (gMonth === 5 && gDay <= 14) {
        bMonth = 0;
        bDay = 18 + gDay;
    } else if (gMonth === 5 && gDay >= 15) {
        bMonth = 1;
        bDay = gDay - 14;
    } else if (gMonth === 6 && gDay <= 14) {
        bMonth = 1;
        bDay = 17 + gDay;
    } else if (gMonth === 6 && gDay >= 15) {
        bMonth = 2;
        bDay = gDay - 14;
    } else if (gMonth === 7 && gDay <= 15) {
        bMonth = 2;
        bDay = 17 + gDay;
    } else if (gMonth === 7 && gDay >= 16) {
        bMonth = 3;
        bDay = gDay - 15;
    } else if (gMonth === 8 && gDay <= 15) {
        bMonth = 3;
        bDay = 16 + gDay;
    } else if (gMonth === 8 && gDay >= 16) {
        bMonth = 4;
        bDay = gDay - 15;
    } else if (gMonth === 9 && gDay <= 15) {
        bMonth = 4;
        bDay = 16 + gDay;
    } else if (gMonth === 9 && gDay >= 16) {
        bMonth = 5;
        bDay = gDay - 15;
    } else if (gMonth === 10 && gDay <= 15) {
        bMonth = 5;
        bDay = 16 + gDay;
    } else if (gMonth === 10 && gDay >= 16) {
        bMonth = 6;
        bDay = gDay - 15;
    } else if (gMonth === 11 && gDay <= 14) {
        bMonth = 6;
        bDay = 16 + gDay;
    } else if (gMonth === 11 && gDay >= 15) {
        bMonth = 7;
        bDay = gDay - 14;
    } else if (gMonth === 12 && gDay <= 14) {
        bMonth = 7;
        bDay = 16 + gDay;
    } else if (gMonth === 12 && gDay >= 15) {
        bMonth = 8;
        bDay = gDay - 14;
    } else if (gMonth === 1 && gDay <= 13) {
        bMonth = 8;
        bDay = 17 + gDay;
    } else if (gMonth === 1 && gDay >= 14) {
        bMonth = 9;
        bDay = gDay - 13;
    } else if (gMonth === 2 && gDay <= 12) {
        bMonth = 9;
        bDay = 18 + gDay;
    } else if (gMonth === 2 && gDay >= 13) {
        bMonth = 10;
        bDay = gDay - 12;
    } else if (gMonth === 3 && gDay <= 14) {
        bMonth = 10;
        bDay = 17 + gDay;
    } else if (gMonth === 3 && gDay >= 15) {
        bMonth = 11;
        bDay = gDay - 14;
    } else if (gMonth === 4 && gDay <= 13) {
        bMonth = 11;
        bDay = 17 + gDay;
    }
    
    return {
        day: bDay,
        month: bMonth,
        year: bYear
    };
}

// Update icon with Bangla date
function updateIcon() {
    const now = new Date();
    const bangla = getBanglaDate(now);
    const banglaDay = toBanglaNumber(bangla.day);
    
    // Create canvas for icon
    const canvas = new OffscreenCanvas(128, 128);
    const ctx = canvas.getContext('2d');
    
    // Background gradient
    const gradient = ctx.createLinearGradient(0, 0, 128, 128);
    gradient.addColorStop(0, '#667eea');
    gradient.addColorStop(1, '#764ba2');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 128, 128);
    
    // Draw date
    ctx.fillStyle = 'white';
    ctx.font = 'bold 72px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(banglaDay, 64, 64);
    
    // Convert canvas to ImageData
    canvas.convertToBlob().then(blob => {
        const reader = new FileReader();
        reader.onload = () => {
            const imageData = reader.result;
            chrome.action.setIcon({
                imageData: ctx.getImageData(0, 0, 128, 128)
            });
        };
        reader.readAsDataURL(blob);
    });
    
    // Simpler approach - just set the badge text
    chrome.action.setBadgeText({ text: banglaDay });
    chrome.action.setBadgeBackgroundColor({ color: '#764ba2' });
}

// Update icon when extension loads
updateIcon();

// Update icon every hour
setInterval(updateIcon, 3600000);

// Update icon at midnight
const now = new Date();
const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
const msUntilMidnight = tomorrow - now;
setTimeout(() => {
    updateIcon();
    setInterval(updateIcon, 86400000); // Update daily
}, msUntilMidnight);