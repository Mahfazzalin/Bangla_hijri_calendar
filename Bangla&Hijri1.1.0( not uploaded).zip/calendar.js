// Bangla months
const banglaMonths = [
    'বৈশাখ', 'জ্যৈষ্ঠ', 'আষাঢ়', 'শ্রাবণ', 'ভাদ্র', 'আশ্বিন',
    'কার্তিক', 'অগ্রহায়ণ', 'পৌষ', 'মাঘ', 'ফাল্গুন', 'চৈত্র'
];

// Hijri months
const hijriMonths = [
    'মুহাররম', 'সফর', 'রবিউল আউয়াল', 'রবিউস সানি', 'জমাদিউল আউয়াল', 'জমাদিউস সানি',
    'রজব', 'শাবান', 'রমজান', 'শাওয়াল', 'জ্বিলকদ', 'জ্বিলহজ্জ'
];

// Bangla numerals
const banglaNumbers = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];

// Convert English number to Bangla
function toBanglaNumber(num) {
    return num.toString().split('').map(d => banglaNumbers[parseInt(d)] || d).join('');
}

// Calculate Bangla date (Bengali Calendar - modified from Gregorian)
function getBanglaDate(date) {
    // Adjust for Bangladesh - one day behind
    const adjustedDate = new Date(date);
    adjustedDate.setDate(adjustedDate.getDate() - 1);
    
    const gYear = adjustedDate.getFullYear();
    const gMonth = adjustedDate.getMonth() + 1; // 1-12
    const gDay = adjustedDate.getDate();
    
    let bYear, bMonth, bDay;
    
    // Bengali New Year starts on April 14 (or April 15 in leap years after 2020)
    if (gMonth < 4 || (gMonth === 4 && gDay < 14)) {
        // Before April 14 = Previous Bengali year (Magh, Falgun, Chaitra)
        bYear = gYear - 594;
    } else {
        // After April 14 = Current Bengali year
        bYear = gYear - 593;
    }
    
    // Month mapping based on Gregorian dates
    // First 5 months (Boishakh to Bhadro) have 31 days
    // Last 7 months (Ashwin to Chaitra) have 30 days
    
    if (gMonth === 4 && gDay >= 14) {
        // Boishakh (April 14 - May 14)
        bMonth = 0;
        bDay = gDay - 13;
    } else if (gMonth === 5 && gDay <= 14) {
        bMonth = 0;
        bDay = 18 + gDay;
    } else if (gMonth === 5 && gDay >= 15) {
        // Jyoishtho (May 15 - June 14)
        bMonth = 1;
        bDay = gDay - 14;
    } else if (gMonth === 6 && gDay <= 14) {
        bMonth = 1;
        bDay = 17 + gDay;
    } else if (gMonth === 6 && gDay >= 15) {
        // Asharh (June 15 - July 15)
        bMonth = 2;
        bDay = gDay - 14;
    } else if (gMonth === 7 && gDay <= 15) {
        bMonth = 2;
        bDay = 17 + gDay;
    } else if (gMonth === 7 && gDay >= 16) {
        // Shrabon (July 16 - August 15)
        bMonth = 3;
        bDay = gDay - 15;
    } else if (gMonth === 8 && gDay <= 15) {
        bMonth = 3;
        bDay = 16 + gDay;
    } else if (gMonth === 8 && gDay >= 16) {
        // Bhadro (August 16 - September 15)
        bMonth = 4;
        bDay = gDay - 15;
    } else if (gMonth === 9 && gDay <= 15) {
        bMonth = 4;
        bDay = 16 + gDay;
    } else if (gMonth === 9 && gDay >= 16) {
        // Ashwin (September 16 - October 15)
        bMonth = 5;
        bDay = gDay - 15;
    } else if (gMonth === 10 && gDay <= 15) {
        bMonth = 5;
        bDay = 16 + gDay;
    } else if (gMonth === 10 && gDay >= 16) {
        // Kartik (October 16 - November 14)
        bMonth = 6;
        bDay = gDay - 15;
    } else if (gMonth === 11 && gDay <= 14) {
        bMonth = 6;
        bDay = 16 + gDay;
    } else if (gMonth === 11 && gDay >= 15) {
        // Ogrohayon (November 15 - December 14)
        bMonth = 7;
        bDay = gDay - 14;
    } else if (gMonth === 12 && gDay <= 14) {
        bMonth = 7;
        bDay = 16 + gDay;
    } else if (gMonth === 12 && gDay >= 15) {
        // Poush (December 15 - January 13)
        bMonth = 8;
        bDay = gDay - 14;
    } else if (gMonth === 1 && gDay <= 13) {
        bMonth = 8;
        bDay = 17 + gDay;
    } else if (gMonth === 1 && gDay >= 14) {
        // Magh (January 14 - February 12)
        bMonth = 9;
        bDay = gDay - 13;
    } else if (gMonth === 2 && gDay <= 12) {
        bMonth = 9;
        bDay = 18 + gDay;
    } else if (gMonth === 2 && gDay >= 13) {
        // Falgun (February 13 - March 14)
        bMonth = 10;
        bDay = gDay - 12;
    } else if (gMonth === 3 && gDay <= 14) {
        bMonth = 10;
        bDay = 17 + gDay;
    } else if (gMonth === 3 && gDay >= 15) {
        // Chaitra (March 15 - April 13)
        bMonth = 11;
        bDay = gDay - 14;
    } else if (gMonth === 4 && gDay <= 13) {
        bMonth = 11;
        bDay = 17 + gDay;
    }
    
    return {
        day: bDay,
        month: bMonth,
        year: bYear,
        monthName: banglaMonths[bMonth]
    };
}

// Calculate Hijri date using accurate algorithm
function getHijriDate(date) {
    // In Islamic calendar, day changes at sunset (approximately 6 PM)
    // If it's after 6 PM, we need to add one day to the date before conversion
    const adjustedDate = new Date(date);
    const hours = adjustedDate.getHours();
    
    // If after 6 PM (18:00), it's the next Islamic day
    if (hours >= 18) {
        adjustedDate.setDate(adjustedDate.getDate() + 1);
    }
    
    // Then apply Bangladesh's one day behind adjustment
    adjustedDate.setDate(adjustedDate.getDate() - 1);
    
    // Convert Gregorian to Julian Day Number
    const gYear = adjustedDate.getFullYear();
    const gMonth = adjustedDate.getMonth() + 1;
    const gDay = adjustedDate.getDate();
    
    let a = Math.floor((14 - gMonth) / 12);
    let y = gYear + 4800 - a;
    let m = gMonth + 12 * a - 3;
    
    let jdn = gDay + Math.floor((153 * m + 2) / 5) + 365 * y + 
              Math.floor(y / 4) - Math.floor(y / 100) + 
              Math.floor(y / 400) - 32045;
    
    // Convert Julian Day Number to Islamic Calendar
    let l = jdn - 1948440 + 10632;
    let n = Math.floor((l - 1) / 10631);
    l = l - 10631 * n + 354;
    let j = (Math.floor((10985 - l) / 5316)) * 
            (Math.floor((50 * l) / 17719)) + 
            (Math.floor(l / 5670)) * 
            (Math.floor((43 * l) / 15238));
    l = l - (Math.floor((30 - j) / 15)) * 
        (Math.floor((17719 * j) / 50)) - 
        (Math.floor(j / 16)) * 
        (Math.floor((15238 * j) / 43)) + 29;
    
    let hMonth = Math.floor((24 * l) / 709);
    let hDay = l - Math.floor((709 * hMonth) / 24);
    let hYear = 30 * n + j - 30;
    
    return {
        day: hDay,
        month: hMonth - 1, // 0-indexed
        year: hYear,
        monthName: hijriMonths[hMonth - 1]
    };
}

// Update date display
function updateDateDisplay() {
    const now = new Date();
    const bangla = getBanglaDate(now);
    const hijri = getHijriDate(now);
    
    document.getElementById('banglaDate').textContent = 
        `${toBanglaNumber(bangla.day)} ${bangla.monthName}, ${toBanglaNumber(bangla.year)}`;
    
    document.getElementById('hijriDate').textContent = 
        `${toBanglaNumber(hijri.day)} ${hijri.monthName}, ${toBanglaNumber(hijri.year)}`;
    
    document.getElementById('gregorianDate').textContent = 
        now.toLocaleDateString('bn-BD', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
        });
}

// Generate calendar for a given month
function generateCalendar(year, month, type, currentDay) {
    const daysInMonth = type === 'bangla' ? 
        (month < 5 ? 31 : 30) : // Bengali: first 5 months have 31 days
        (month % 2 === 0 ? 30 : 29); // Hijri: alternating 30/29
    
    const calendar = [];
    
    // Add day headers
    const dayHeaders = ['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহ', 'শুক্র', 'শনি'];
    dayHeaders.forEach((day, index) => {
        calendar.push({ 
            type: 'header', 
            value: day,
            isFriday: index === 5 // Friday is index 5 (শুক্র)
        });
    });
    
    // Calculate starting day of week (simplified approximation)
    const startDay = (month * 2 + year) % 7;
    
    // Add empty cells
    for (let i = 0; i < startDay; i++) {
        calendar.push({ type: 'empty', value: '' });
    }
    
    // Add days
    for (let day = 1; day <= daysInMonth; day++) {
        const dayOfWeek = (startDay + day - 1) % 7;
        calendar.push({ 
            type: 'date', 
            value: toBanglaNumber(day),
            isToday: day === currentDay,
            isFriday: dayOfWeek === 5 // Friday column
        });
    }
    
    return calendar;
}

// Render calendar
function renderCalendar(containerId, calendar) {
    const container = document.getElementById(containerId);
    container.innerHTML = '';
    
    calendar.forEach(day => {
        const div = document.createElement('div');
        div.className = `calendar-day ${day.type}`;
        if (day.isToday) div.classList.add('today');
        if (day.isFriday) div.classList.add('friday');
        div.textContent = day.value;
        container.appendChild(div);
    });
}

// Current calendar state
let currentBangla = getBanglaDate(new Date());
let currentHijri = getHijriDate(new Date());

// Update full calendar view
function updateCalendarView() {
    // Bangla calendar
    document.getElementById('banglaMonthYear').textContent = 
        `${banglaMonths[currentBangla.month]} ${toBanglaNumber(currentBangla.year)}`;
    const banglaCalendar = generateCalendar(
        currentBangla.year, 
        currentBangla.month, 
        'bangla',
        currentBangla.day
    );
    renderCalendar('banglaCalendar', banglaCalendar);
    
    // Hijri calendar
    document.getElementById('hijriMonthYear').textContent = 
        `${hijriMonths[currentHijri.month]} ${toBanglaNumber(currentHijri.year)}`;
    const hijriCalendar = generateCalendar(
        currentHijri.year, 
        currentHijri.month, 
        'hijri',
        currentHijri.day
    );
    renderCalendar('hijriCalendar', hijriCalendar);
}

// Event listeners
document.getElementById('openCalendarBtn').addEventListener('click', () => {
    document.getElementById('dateView').style.display = 'none';
    document.getElementById('calendarView').style.display = 'block';
    document.body.style.width = '350px';
    document.body.style.height = 'auto';
    updateCalendarView();
});

document.getElementById('backBtn').addEventListener('click', () => {
    document.getElementById('calendarView').style.display = 'none';
    document.getElementById('dateView').style.display = 'block';
    document.body.style.width = '320px';
});

document.getElementById('prevBangla').addEventListener('click', () => {
    currentBangla.month--;
    if (currentBangla.month < 0) {
        currentBangla.month = 11;
        currentBangla.year--;
    }
    updateCalendarView();
});

document.getElementById('nextBangla').addEventListener('click', () => {
    currentBangla.month++;
    if (currentBangla.month > 11) {
        currentBangla.month = 0;
        currentBangla.year++;
    }
    updateCalendarView();
});

document.getElementById('prevHijri').addEventListener('click', () => {
    currentHijri.month--;
    if (currentHijri.month < 0) {
        currentHijri.month = 11;
        currentHijri.year--;
    }
    updateCalendarView();
});

document.getElementById('nextHijri').addEventListener('click', () => {
    currentHijri.month++;
    if (currentHijri.month > 11) {
        currentHijri.month = 0;
        currentHijri.year++;
    }
    updateCalendarView();
});

// Initialize
updateDateDisplay();