// Bangla numerals
const banglaNumbers = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];

// Convert English number to Bangla
function toBanglaNumber(num) {
    return num.toString().split('').map(d => banglaNumbers[parseInt(d)] || d).join('');
}

// Calculate Bangla date
function getBanglaDate(date) {
    // Adjust for Bangladesh - one day behind
    const adjustedDate = new Date(date);
    adjustedDate.setDate(adjustedDate.getDate() - 1);
    
    const gYear = adjustedDate.getFullYear();
    const gMonth = adjustedDate.getMonth() + 1;
    const gDay = adjustedDate.getDate();
    
    let bYear, bMonth, bDay;
    
    if (gMonth < 4 || (gMonth === 4 && gDay < 14)) {
        bYear = gYear - 594;
    } else {
        bYear = gYear - 593;
    }
    
    if (gMonth === 4 && gDay >= 14) {
        bMonth = 0;
        bDay = gDay - 13;
    } else if (gMonth === 5 && gDay <= 14) {
        bMonth = 0;
        bDay = 18 + gDay;
    } else if (gMonth === 5 && gDay >= 15) {
        bMonth = 1;
        bDay = gDay - 14;
    } else if (gMonth === 6 && gDay <= 14) {
        bMonth = 1;
        bDay = 17 + gDay;
    } else if (gMonth === 6 && gDay >= 15) {
        bMonth = 2;
        bDay = gDay - 14;
    } else if (gMonth === 7 && gDay <= 15) {
        bMonth = 2;
        bDay = 17 + gDay;
    } else if (gMonth === 7 && gDay >= 16) {
        bMonth = 3;
        bDay = gDay - 15;
    } else if (gMonth === 8 && gDay <= 15) {
        bMonth = 3;
        bDay = 16 + gDay;
    } else if (gMonth === 8 && gDay >= 16) {
        bMonth = 4;
        bDay = gDay - 15;
    } else if (gMonth === 9 && gDay <= 15) {
        bMonth = 4;
        bDay = 16 + gDay;
    } else if (gMonth === 9 && gDay >= 16) {
        bMonth = 5;
        bDay = gDay - 15;
    } else if (gMonth === 10 && gDay <= 15) {
        bMonth = 5;
        bDay = 16 + gDay;
    } else if (gMonth === 10 && gDay >= 16) {
        bMonth = 6;
        bDay = gDay - 15;
    } else if (gMonth === 11 && gDay <= 14) {
        bMonth = 6;
        bDay = 16 + gDay;
    } else if (gMonth === 11 && gDay >= 15) {
        bMonth = 7;
        bDay = gDay - 14;
    } else if (gMonth === 12 && gDay <= 14) {
        bMonth = 7;
        bDay = 16 + gDay;
    } else if (gMonth === 12 && gDay >= 15) {
        bMonth = 8;
        bDay = gDay - 14;
    } else if (gMonth === 1 && gDay <= 13) {
        bMonth = 8;
        bDay = 17 + gDay;
    } else if (gMonth === 1 && gDay >= 14) {
        bMonth = 9;
        bDay = gDay - 13;
    } else if (gMonth === 2 && gDay <= 12) {
        bMonth = 9;
        bDay = 18 + gDay;
    } else if (gMonth === 2 && gDay >= 13) {
        bMonth = 10;
        bDay = gDay - 12;
    } else if (gMonth === 3 && gDay <= 14) {
        bMonth = 10;
        bDay = 17 + gDay;
    } else if (gMonth === 3 && gDay >= 15) {
        bMonth = 11;
        bDay = gDay - 14;
    } else if (gMonth === 4 && gDay <= 13) {
        bMonth = 11;
        bDay = 17 + gDay;
    }
    
    return {
        day: bDay,
        month: bMonth,
        year: bYear
    };
}

// Update icon with Bangla date
function updateIcon() {
    const now = new Date();
    const bangla = getBanglaDate(now);
    const banglaDay = toBanglaNumber(bangla.day);
    
    // Set badge text and color
    chrome.action.setBadgeText({ text: banglaDay });
    chrome.action.setBadgeBackgroundColor({ color: '#764ba2' });
    
    // Store the badge text so it persists
    chrome.storage.local.set({ 
        badgeText: banglaDay,
        lastUpdate: now.toDateString()
    });
}

// Update icon when extension loads
updateIcon();

// Check and update if needed on startup
chrome.runtime.onStartup.addListener(() => {
    updateIcon();
});

// Update when browser starts
chrome.runtime.onInstalled.addListener(() => {
    updateIcon();
});

// Update icon every hour
setInterval(updateIcon, 3600000);

// Update icon at midnight
const now = new Date();
const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
const msUntilMidnight = tomorrow - now;
setTimeout(() => {
    updateIcon();
    setInterval(updateIcon, 86400000); // Update daily
}, msUntilMidnight);

// Restore badge on browser restart
chrome.storage.local.get(['badgeText', 'lastUpdate'], function(result) {
    if (result.badgeText) {
        const lastUpdate = new Date(result.lastUpdate);
        const today = new Date();
        
        // If it's the same day, restore the badge
        if (lastUpdate.toDateString() === today.toDateString()) {
            chrome.action.setBadgeText({ text: result.badgeText });
            chrome.action.setBadgeBackgroundColor({ color: '#764ba2' });
        } else {
            // Otherwise update it
            updateIcon();
        }
    }
});

// Handle alarms for event notifications
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name.startsWith('event_')) {
        // Get event info from storage
        chrome.storage.local.get([`alarm_${alarm.name}`], function(result) {
            const eventData = result[`alarm_${alarm.name}`];
            if (eventData) {
                // Show notification
                chrome.notifications.create({
                    type: 'basic',
                    iconUrl: 'icon128.png',
                    title: `🔔 ${eventData.title}`,
                    message: eventData.description || `ইভেন্ট সময়: ${eventData.time}`,
                    priority: 2
                });
                
                // Clean up storage
                chrome.storage.local.remove([`alarm_${alarm.name}`]);
            }
        });
    }
});